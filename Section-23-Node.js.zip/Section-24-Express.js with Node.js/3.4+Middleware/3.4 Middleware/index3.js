import express from "express";//  express is a web framework for node.js that makes it easy to build web applications and APIs

const app = express();
const port = 3000;


function logger(req, res, next) {
  console.log("Request Method:", req.method);
  console.log("Request URL:", req.url);
  next();
}//logger is a middleware function that logs the request method and URL to the console. It takes in the request, response, and next objects as arguments. The next() function is called to pass control to the next middleware function in the stack.

app.use(logger);//app.use is used to mount the logger middleware function to the application. It will be executed for every incoming request to the server.

app.get("/", (req, res) => {
  res.send("Hello");
});//app.get is used to define a route for the GET method. The first argument is the path, and the second argument is a callback function that takes in the request and response objects. The callback function sends a response back to the client.

app.listen(port, () => {
  console.log(`Listening on port ${port}`);
});//app.listen is used to start the server and listen for incoming requests on the specified port. The first argument is the port number, and the second argument is a callback function that is called when the server starts listening. The callback function logs a message to the console indicating that the server is listening on the specified port.
