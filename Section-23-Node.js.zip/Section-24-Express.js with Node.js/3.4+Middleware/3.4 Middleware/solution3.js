import express from "express";

const app = express();
const port = 3000;

function logger(req, res, next) {
  console.log("Request Method: ", req.method);
  console.log("Request URL: ", req.url);
  next();
}//logger is a middleware function that logs the request method and URL to the console. It takes in three arguments: req, res, and next. The req object contains information about the incoming request, the res object is used to send a response back to the client, and the next function is called to pass control to the next middleware function in the stack.

app.use(logger);//app.use is used to mount the logger middleware function to the application. It takes in one argument: the middleware function to be mounted. The logger function will be called for every incoming request to the server.

app.get("/", (req, res) => {
  res.send("Hello");
}); //app.get is used to define a route for the GET method. The first argument is the path, and the second argument is a callback function that takes in the request and response objects. The callback function sends a response back to the client.

app.listen(port, () => {
  console.log(`Listening on port ${port}`);
});//app.listen is used to start the server and listen for incoming requests on the specified port. The first argument is the port number, and the second argument is a callback function that is called when the server starts listening. The callback function logs a message to the console indicating that the server is listening on the specified port.
