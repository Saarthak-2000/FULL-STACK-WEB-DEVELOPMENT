import express from "express";//express is a web framework for node.js that makes it easy to build web applications and APIs
import bodyParser from "body-parser";//body parser is used to parse the body of the request and make it available in req.body
import { dirname } from "path";//dirname is used to get the directory name of the current module
import { fileURLToPath } from "url";//fileURLToPath is used to convert a file URL to a path
const __dirname = dirname(fileURLToPath(import.meta.url));//__dirname is used to get the directory name of the current module

const app = express();//app is an instance of express
const port = 3000;//port is the port number on which the server will listen


app.use(bodyParser.urlencoded({ extended: true }));//body parser is used to parse the body of the request and make it available in req.body

app.get("/", (req, res) => {
  //console.log(__dirname + "/public/index.html");
  res.sendFile(__dirname + "/public/index.html");
});//sendFile is used to send a file as a response to the client


app.post("/submit", (req, res) => {
  console.log(req.body);
});//req.body is used to get the body of the request


app.listen(port, () => {
  console.log(`Listening on port ${port}`);
});//listen is used to start the server and listen for incoming requests on the specified port 
