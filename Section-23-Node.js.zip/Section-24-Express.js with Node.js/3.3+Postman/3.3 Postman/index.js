import express from "express";
const app = express();
const port = 3000;

// *********************
// Let’s practice using Postman. Make sure your server is running with nodemon.
// Then test the 5 different routes below with Postman. Open a separate tab for each request.
// Check that for each route you’re getting the correct status code returned to you from your server.
// You should not get any 404s or 500 status codes.
// *********************

app.get("/", (req, res) => {
  res.send("<h1>Home Page</h1>");
  //This is the home page
});

app.post("/register", (req, res) => {
  //Do something with the data
  res.sendStatus(201);
  //Creating a new user. Register route is used to create a new user. The server responds with a 201 status code to indicate that the user was created successfully.
});

app.put("/user/angela", (req, res) => {
  res.sendStatus(200);
    //Updating user angela. Put request is used to update a resource. In this case, we are updating the user "angela". The server responds with a 200 status code to indicate that the update was successful.
});

app.patch("/user/angela", (req, res) => {
  res.sendStatus(200);
  //Updating user angela. Patch request is used to make partial updates to a resource. In this case, we are making a partial update to the user "angela". The server responds with a 200 status code to indicate that the update was successful.
});

app.delete("/user/angela", (req, res) => {
  //Deleting user angela. Delete request is used to delete a resource. In this case, we are deleting the user "angela". The server responds with a 200 status code to indicate that the deletion was successful.
  res.sendStatus(200);
});

app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
