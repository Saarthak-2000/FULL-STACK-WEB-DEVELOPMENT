//jshint esversion:6

const express=require('express');
const bodyParser=require('body-parser');

const app=express();
app.use(bodyParser.urlencoded({extended:true}));

app.get("/", function(req, res) {
  res.sendFile(__dirname + "/Calculation.html");
});

app.post("/", function(req, res) {
  var num1 = Number(req.body.num1);
  var num2 = Number(req.body.num2);
  var result;

  switch (req.body.operation) {
    case "add":
      result = num1 + num2;
      break;
    case "subtract":
      result = num1 - num2;
      break;
    case "multiply":
      result = num1 * num2;
      break;
    case "divide":
      if (num2 === 0) {
        return res.status(400).send("Cannot divide by zero");
      }
      result = num1 / num2;
      break;
    default:
      return res.status(400).send("Choose a valid operation");
  }

  res.send("The result of the calculation is " + result);
});

app.get("/bmicalculator", function(req, res) {
    res.sendFile(__dirname + "/bmiCalculator.html");
});
app.post("/bmicalculator", function(req, res) {
    var weight=parseFloat(req.body.weight);
    var height=parseFloat(req.body.height);
    var bmi=weight/(height*height);
    res.send("Your BMI is " + bmi);
});//bmi calcuate karna hai tabh localhost:3000/bmicalcutor type karna search bar me tab jakar bmi calculator ka html page open hoga

app.listen(3000, function() {
    console.log("Server started on port 3000");
});






