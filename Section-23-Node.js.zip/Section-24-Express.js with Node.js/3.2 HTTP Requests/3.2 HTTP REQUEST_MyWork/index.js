import express from "express";
const app = express();
const port = 3000;

app.get("/", (req, res) => {
    console.log(req.rawHeaders);
    res.send("<h1>HELLO</h1>");
});

app.get("/about", (req, res) => {
    console.log(req.rawHeaders);
    res.send("<h1>ABOUT ME</h1><<p>My name is KAARTIK . I am a web developer</p>");
});

app.get("/Contact", (req, res) => {
    console.log(req.rawHeaders);
    res.send("<h1>CONTACT ME</h1><p>You can reach me at kaartik@example.com</p>");
});


app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});